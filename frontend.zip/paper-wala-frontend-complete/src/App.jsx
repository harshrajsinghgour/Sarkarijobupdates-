import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft, Bell, Building2, CalendarDays, ChevronRight, Download,
  ExternalLink, FileText, GraduationCap, IdCard, IndianRupee, KeyRound,
  Menu, Mic, MoreHorizontal, Search, Trophy, X, Clock3, Home, Sparkles
} from "lucide-react";
import { categories, items } from "./data";

const iconMap = { bell: Bell, file: FileText, id: IdCard, key: KeyRound, trophy: Trophy, more: MoreHorizontal };

function App() {
  const [active, setActive] = useState("updates");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [menu, setMenu] = useState(false);
  const [toast, setToast] = useState("");

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((item) => {
      const categoryOk = active === "updates" || active === "more" || item.category === active;
      const text = `${item.title} ${item.organization} ${item.description}`.toLowerCase();
      return categoryOk && (!q || text.includes(q));
    });
  }, [active, query]);

  useEffect(() => {
    document.title = selected ? `${selected.title} | Paper Wala` : "Paper Wala";
  }, [selected]);

  const go = (id) => {
    setActive(id);
    setSelected(null);
    setMenu(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const voice = () => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
      setToast("इस browser में voice search available नहीं है.");
      return;
    }
    const r = new Recognition();
    r.lang = "hi-IN";
    r.interimResults = false;
    r.onstart = () => setToast("बोलिए, मैं सुन रहा हूँ...");
    r.onresult = (e) => {
      const value = e.results[0][0].transcript;
      setQuery(value);
      setToast(`Search: ${value}`);
    };
    r.onerror = () => setToast("Microphone permission check करें.");
    r.onend = () => setTimeout(() => setToast(""), 2200);
    r.start();
  };

  const openItem = (item) => {
    setSelected(item);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => go("updates")}>
          <span className="brand-mark">P</span>
          <span className="brand-copy">
            <b>paper wala</b>
            <small>Education & Exam Platform</small>
          </span>
        </button>

        <SearchBox value={query} setValue={setQuery} onVoice={voice} />

        <button className="mobile-menu-btn" onClick={() => setMenu((v) => !v)} aria-label="Menu">
          {menu ? <X size={21} /> : <Menu size={21} />}
        </button>
      </header>

      {menu && (
        <div className="mobile-panel">
          <SearchBox value={query} setValue={setQuery} onVoice={voice} />
          <div className="mobile-links">
            {categories.map((cat) => {
              const Icon = iconMap[cat.icon];
              return (
                <button key={cat.id} className={active === cat.id ? "active" : ""} onClick={() => go(cat.id)}>
                  <Icon size={18} /> {cat.title}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <main className="page">
        {selected ? (
          <DetailPage item={selected} onBack={() => setSelected(null)} />
        ) : (
          <>
            <Hero onExplore={() => go("updates")} />
            <QuickAccess active={active} onChange={go} />
            <section className="content-section">
              <div className="section-heading">
                <div>
                  <small>LATEST</small>
                  <h2>{categories.find((x) => x.id === active)?.title}</h2>
                </div>
                <button className="view-all" onClick={() => { setActive("updates"); setQuery(""); }}>
                  View All <ChevronRight size={17} />
                </button>
              </div>

              <div className="cards-grid">
                {visible.length ? visible.map((item) => (
                  <UpdateCard key={item.id} item={item} onOpen={() => openItem(item)} />
                )) : (
                  <div className="empty-state">
                    <Search size={35} />
                    <h3>No Result Found</h3>
                    <p>Search या category बदलकर देखें.</p>
                  </div>
                )}
              </div>
            </section>
          </>
        )}
      </main>

      <BottomNav active={active} onChange={go} />

      {toast && (
        <div className="toast">
          <span>{toast}</span>
          <button onClick={() => setToast("")}><X size={16} /></button>
        </div>
      )}
    </div>
  );
}

function SearchBox({ value, setValue, onVoice }) {
  return (
    <div className="search-box">
      <Search size={20} />
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Search here..."
        aria-label="Search"
      />
      <button className="voice-btn" onClick={onVoice} aria-label="Voice search">
        <Mic size={19} />
      </button>
    </div>
  );
}

function Hero({ onExplore }) {
  return (
    <section className="hero">
      <div className="hero-copy">
        <span className="eyebrow">PAPER WALA</span>
        <h1>Stay Updated,<br /><em>Stay Ahead!</em></h1>
        <p>Exam updates, syllabus, admit cards, answer keys और results — सब एक जगह.</p>
        <button className="hero-btn" onClick={onExplore}>Explore Updates <ChevronRight size={18} /></button>
      </div>
      <div className="hero-art" aria-hidden="true">
        <div className="art-sheet">
          <div className="art-clip"></div>
          <div className="art-line"><i>✓</i><span></span></div>
          <div className="art-line"><i>✓</i><span></span></div>
          <div className="art-line"><i>✓</i><span></span></div>
        </div>
        <div className="art-book book-a"></div>
        <div className="art-book book-b"></div>
        <Sparkles className="art-spark" size={38} />
      </div>
    </section>
  );
}

function QuickAccess({ active, onChange }) {
  return (
    <section className="quick-section">
      <div className="section-heading">
        <div><small>QUICK ACCESS</small><h2>Exam Services</h2></div>
      </div>
      <div className="quick-grid">
        {categories.map((cat) => {
          const Icon = iconMap[cat.icon];
          return (
            <button key={cat.id} className={`quick-card ${active === cat.id ? "selected" : ""}`} onClick={() => onChange(cat.id)}>
              <span className={`quick-icon ${cat.tone}`}><Icon size={26} /></span>
              <b>{cat.title}</b>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function UpdateCard({ item, onOpen }) {
  return (
    <article className="update-card" onClick={onOpen}>
      <div className="card-media">
        <img src={item.image} alt="" />
        <span>{item.tag}</span>
      </div>
      <div className="card-body">
        <div className="date-line"><CalendarDays size={14} /> {item.date}</div>
        <h3>{item.title}</h3>
        <p>{item.description}</p>
        <button className="read-btn">Read Details <ChevronRight size={16} /></button>
      </div>
    </article>
  );
}

function DetailPage({ item, onBack }) {
  return (
    <section className="detail-page">
      <button className="back-btn" onClick={onBack}><ArrowLeft size={18} /> Back</button>
      <article className="detail-card">
        <div className="detail-cover">
          <img src={item.image} alt="" />
          <span>{item.tag}</span>
        </div>
        <div className="detail-body">
          <div className="date-line"><CalendarDays size={15} /> {item.date}</div>
          <h1>{item.title}</h1>
          <div className="org-line"><Building2 size={17} /> {item.organization}</div>
          <hr />
          <h2>Full Details</h2>
          <p className="lead">{item.description}</p>

          <div className="info-grid">
            <InfoBox icon={Clock3} title="Important Dates">
              <ul>{item.dates.map((x) => <li key={x}>{x}</li>)}</ul>
            </InfoBox>
            <InfoBox icon={GraduationCap} title="Eligibility"><p>{item.eligibility}</p></InfoBox>
            <InfoBox icon={IndianRupee} title="Application Fee"><p>{item.fee}</p></InfoBox>
            <InfoBox icon={FileText} title="Documents"><p>{item.documents}</p></InfoBox>
          </div>

          <div className="detail-actions">
            <button className="primary-btn"><ExternalLink size={17} /> Official Website</button>
            <button className="secondary-btn"><Download size={17} /> Download</button>
          </div>
        </div>
      </article>
    </section>
  );
}

function InfoBox({ icon: Icon, title, children }) {
  return (
    <div className="info-box">
      <div className="info-title"><Icon size={18} /> {title}</div>
      <div className="info-content">{children}</div>
    </div>
  );
}

function BottomNav({ active, onChange }) {
  return (
    <nav className="bottom-nav">
      <button className={active === "updates" ? "active" : ""} onClick={() => onChange("updates")}>
        <Home size={20} /><span>Updates</span>
      </button>
      {categories.slice(1).map((cat) => {
        const Icon = iconMap[cat.icon];
        return (
          <button key={cat.id} className={active === cat.id ? "active" : ""} onClick={() => onChange(cat.id)}>
            <Icon size={20} /><span>{cat.short}</span>
          </button>
        );
      })}
    </nav>
  );
}

export default App;